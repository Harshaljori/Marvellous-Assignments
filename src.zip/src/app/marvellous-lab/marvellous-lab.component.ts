import { Component } from '@angular/core';

@Component({
  selector: 'app-marvellous-lab',
  templateUrl: './marvellous-lab.component.html',
  styleUrls: ['./marvellous-lab.component.css']
})
export class MarvellousLabComponent {

}
