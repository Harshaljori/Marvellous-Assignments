import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarvellousLabComponent } from './marvellous-lab.component';

describe('MarvellousLabComponent', () => {
  let component: MarvellousLabComponent;
  let fixture: ComponentFixture<MarvellousLabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MarvellousLabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MarvellousLabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
