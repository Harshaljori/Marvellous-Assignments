import { Component } from '@angular/core';

@Component({
  selector: 'app-texttransform',
  templateUrl: './texttransform.component.html',
  styleUrls: ['./texttransform.component.css']
})
export class TexttransformComponent {

   str1 : string = "Marvellous Infosystem";

  public Uppercase()
  {
   
     this.str1 = this.str1.toUpperCase();
    
  }
  public Lowercase()
  {
   
     this.str1 = this.str1.toLowerCase();
    
  }

 

}
