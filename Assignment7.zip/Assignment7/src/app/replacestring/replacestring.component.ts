import { Component } from '@angular/core';

@Component({
  selector: 'app-replacestring',
  templateUrl: './replacestring.component.html',
  styleUrls: ['./replacestring.component.css']
})
export class ReplacestringComponent {

  textToChange = 'Marvellous Infosystem';

  changeTheText() {
    this.textToChange = 'Educating For Better Tommorow';
  }


}
