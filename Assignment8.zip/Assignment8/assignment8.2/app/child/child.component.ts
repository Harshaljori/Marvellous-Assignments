import { Component,Input,Output,EventEmitter,OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {
  @Input() public parentData : string ="";

  @Output() public childData = new EventEmitter();

  public SendEvent()
  {
    // Send the event to parent
    this.childData.emit('Hello from child');
  }

   

  constructor()
  {

  }
  OnInit()
  {

  }
}
