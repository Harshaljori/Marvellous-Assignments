import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {
 
  @Output() public MyEvent = new EventEmitter();

  sendmessage()
  {
      this.MyEvent.emit("hello from component");
  }
  
  ngOnInit() {
  }

}

