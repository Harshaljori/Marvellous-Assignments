import { Directive } from '@angular/core';
import {ElementRef, HostListener} from '@angular/core';
@Directive({
  selector: '[appCustomStyle]'
})
export class CustomStyleDirective {

 constructor(private ele:ElementRef) 
  {
    //ele.nativeElement.style.background='yellow'
  }

  @HostListener('mouseenter') onmouseenter()
  {
    this.setcolor('yellow');
    this.setfontweight("bold")
  }

  @HostListener('mouseleave') onmouseleave()
  {
    this.setcolor('white');
    this.setfontweight("light")
  }

  setcolor(color:string)
  {
    this.ele.nativeElement.style.background=color;
   
  }
   setfontweight(weight:any)
  {
   
    this.ele.nativeElement.style.fontweight=weight;
   
  }
}
